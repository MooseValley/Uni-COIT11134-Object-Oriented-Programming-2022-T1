/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07payableemployee;

/**
 *
 * @author omalleym
 */
public class SalariedEmployee extends Employee //implements Payable
{
    private double annualSalary;
    
    public SalariedEmployee ()
    {
        super ("", "", "");
        annualSalary = 0.0;
    }

    public SalariedEmployee (String firstName, String lastName, String socialSecurityNumber, double annualSalary)
    {
        super (firstName, lastName, socialSecurityNumber);

        this.annualSalary = annualSalary;
    }
    
    public double getAnnualSalary ()
    {
        return annualSalary;
    }
    
    public double getPaymentAmount ()
    {
        return annualSalary;
    }

    public void setAnnualSalary (double annualSalary)
    {
        this.annualSalary = annualSalary;
    }
    
    @Override
    public String toString ()
    {
        return super.toString() + ", Salary: $" + String.format ("%,.2f", annualSalary);
    }
}
