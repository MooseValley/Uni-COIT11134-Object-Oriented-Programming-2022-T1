/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w07payableemployee;


import java.util.ArrayList;


/**
 *
 * @author omalleym
 */
public class W07PayableEmployee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        SalariedEmployee emp1 = new SalariedEmployee ("Mike", "O", "1234", 100);
        
        emp1.setAnnualSalary (110.0);
        emp1.setLastName ("OMalley");
        
        System.out.println (emp1);
        System.out.println ("Employee 1's payment amount = " + emp1.getPaymentAmount() );
        
        
        Invoice inv1 = new Invoice ("W001",  "Widget",        300,    0.17);
        Invoice inv2 = new Invoice ("CP313", "Core i7 CPU",     5,  400.99);

        System.out.println (inv1);
        System.out.println ("Invoice 1's payment amount = " + inv1.getPaymentAmount() );
        System.out.println (inv2);
        System.out.println ("Invoice 2's payment amount = " + inv2.getPaymentAmount() );
        
        
        // Employee and Invoice are completely different types of data ...
        // You probably don't want to create a single storage array for all Employees and Invoices ??
        // But if you want to, you can !  :)
        
        ArrayList<Payable> payableArrayList = new ArrayList<>();
        
        payableArrayList.add (emp1);
        payableArrayList.add (inv1);
        payableArrayList.add (inv2);
        
        for (Payable p : payableArrayList)
        {
            System.out.println (p);
            
            if (p instanceof Invoice)
            {
                if ( ((Invoice)p).getQuantity() > 100)
                    System.out.println ("--> you get a 10% discount"); 
            }
        }
    }
    
}
