/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2x;

/**
 *
 * @author uvenu
 */
public class MyQueueTest {
     public static void main(String [] args){
       // creating an IntQ object to add Integer values
      MyQueue <Integer> q = new MyQueue <>();
        int a1Mark = 12; 
        int a2Mark = 21;
        
// Student should add an integer value (e.g., 67) to the queue q
        q.add(a1Mark); 
// Student should add any three integer values (e.g., 7,24, 56) to the queue q
        q.add(a2Mark);
        System.out.println(q.peek() + " peek value ");
        System.out.println(q.remove() +" removed value");
        System.out.println(q.peek()+ " peek value ");
        System.out.println("All values in the queue are removed now");
        while (!q.isEmpty()){         
            System.out.print(q.remove() + " ");
        }
    } 
} // End of CheckQ class

  