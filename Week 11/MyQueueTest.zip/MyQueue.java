/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w2x;
import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
/**
 *
 * @author uvenu
 */


public class MyQueue<T> extends AbstractQueue<T>{
            
    List<T> aList = new LinkedList<>();
        @Override
        public int size(){ 
            return aList.size();
        }
        @Override
        public Iterator<T> iterator(){
            return aList.listIterator();         
        }
        @Override
        public boolean offer(T item){
            aList.add(item); 
            return true;
        }
        @Override             
        public T poll(){
            return aList.remove(0); 
        }

        @Override
        public T peek(){
            return aList.get(0);
        }
    } // end of MyQueue
