/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w11q02linkedliststack;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Stack;

/**
 *
 * @author omalleym
 */
public class W11Q02LinkedListStack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        LinkedList<ContainerBox> dock = new LinkedList<>();

        dock.add (new ContainerBox (1, "China Shipping",   "400 kent St",              4800.0) );
        dock.add (new ContainerBox (2, "ABC Company",      "Sydney Marketers Pty ltd", 23500.0) );
        dock.add (new ContainerBox (3, "ABC Company",      "Chrome pty Ltd",           17500.0) );
        dock.add (new ContainerBox (4, "Columbian Coffee", "Sydney Marketers Pty ltd", 26000.0) );
    
        /*
        c) Using a ListIterator, identify and remove the Containerbox object that has the containerId value 4.  
        Display the contents of dock on the screen.
        */

        System.out.println ("*** ListIterator:");

        ListIterator<ContainerBox> iterator = dock.listIterator();
        while(iterator.hasNext() == true)
        {
            if (iterator.next().getContainerId() == 4)
                iterator.remove();
        }
        
        for (ContainerBox c : dock)
        {
            System.out.println (c);
        }

        
        /*
        d) Create a Stack object and push all the objects from the dock into the Stack object. 
        Use pop method to display the contents of the Stack object on the screen.
        */
        
        System.out.println ("*** Stack:");

        Stack<ContainerBox> dockStack = new Stack<>();
        
        /*
        for (ContainerBox c : dock)
        {
            dockStack.push (c);
        }
        */
        for (int k = 0; k < dock.size(); k++)
        {
            dockStack.push (dock.get(k) );
        }
        
        
        for (ContainerBox c : dockStack) // For Each works great with Stacks, ArrayList, LinkedList, etc
        {
            System.out.println (c);
        }
        
        
        while (dockStack.empty() == false)
        {
            System.out.println (dockStack.pop() );
        }
        
        
    }

}
