/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w11q02linkedliststack;

/**
 *
 * @author omalleym
 */
public class ContainerBox 
{
    private int containerId;
    
    private String from;
    private String deliverTo;
    private double value;

    public ContainerBox ()
    {
        this (0, "", "", 0.0);
    }
    
    public ContainerBox (int containerId, String from, String deliverTo, double value)
    {
        this.containerId = containerId;
        this.from        = from;
        this.deliverTo   = deliverTo;
        this.value       = value;
    }
    
    public int getContainerId ()
    {
        return containerId;
    }
    
    @Override
    public String toString ()
    {
        return String.format ("%05d",    containerId) + " " +
               String.format ("%-25s",   from)        + " " +
               String.format ("%-25s",   deliverTo)   + " " +
         "$" + String.format ("%,11.2f", value)       + " ";
    }
}
