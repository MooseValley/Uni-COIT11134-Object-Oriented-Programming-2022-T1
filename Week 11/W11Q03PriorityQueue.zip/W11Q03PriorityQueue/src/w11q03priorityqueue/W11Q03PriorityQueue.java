/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w11q03priorityqueue;

import java.util.PriorityQueue;
import java.util.Queue;

/**
 *
 * @author omalleym
 */
public class W11Q03PriorityQueue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        Queue<Integer> myQueue = new PriorityQueue<> ();
        
        myQueue.add (777);
        myQueue.add (11);
        myQueue.add (3);
        myQueue.add (99);
        myQueue.add (666);

        for (Integer i : myQueue)
            System.out.println (i);
    }
    
}
