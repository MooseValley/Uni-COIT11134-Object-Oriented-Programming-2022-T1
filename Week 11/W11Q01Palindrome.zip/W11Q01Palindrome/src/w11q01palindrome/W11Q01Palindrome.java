/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w11q01palindrome;

import java.util.Stack;

/**
 *
 * @author omalleym
 */
public class W11Q01Palindrome 
{
    
    public static boolean isPalindrome (String str)
    {
        Stack<Character> charStack = new Stack<>();
        boolean result = true; // And try and prove otherwise.
        
        // Convert to lowercase
        str = str.toLowerCase();
                
        // Remove spaces, ",", "."
        // Could use isLetter, isAlphabetic, etc instead ...
        str = str.replace (" ", "");
        str = str.replace (",", "");
        str = str.replace (".", "");
        str = str.replace ("'", "");
        str = str.replace ("!", "");
        

        // Get letters - charAt - and push them on a Stack
        for (int k = 0; k < str.length() / 2; k++)
        //for (int k = 0; k < str.length(); k++)
        {
            charStack.push (str.charAt (k) );
        }
        
        
        // Read them back and compare to original and see if they all match
        for (int k = str.length() / 2 + 1; k < str.length(); k++)
        //for (int k = 0; k < str.length(); k++)
        {
            if (charStack.pop() != str.charAt (k) )
                result = false;
        }
        
        
        // return result
        return result;        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        String[] phrases = {"Racecar", "kayak", "Dammit, I'm Mad !!", "Frankie"};
        
        for (String s: phrases)
            System.out.println (s + ": " + isPalindrome (s) );
        
    }
    
}
