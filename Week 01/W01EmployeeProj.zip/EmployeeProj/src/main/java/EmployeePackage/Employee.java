/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeePackage;

import javax.swing.JOptionPane;
/*

Primative Types
int
double
char
boolean

int k = 0;

Reference Types
String
Date
Employee


String name = "Mike";
Employee emp1 = new Employee (::::::::);


    emp1 ----->   name: <unknown>
                  salary: 0

    emp2 --------> name: Frank
                   salary: 110


Object class
public class Employee

public class Employee extends Object


Object o1 = "Mike";

o1 = 123;

o1 = new Date();


Computer Game
Player
Monster
Scenery - destructible and non-destruct
Non-Player characters

Player p1 = new Player();
p1.addToGameWorld();

Monster m1 = new Monster("Skeleton", 100, 10);
m1.addToGameWorld();

Override can save your bacon when you are dealing with complex projects, lots of classes and methods.




*/
/**
 *
 * @author omalleym
 */
public class Employee 
{
    private String name;  
    private double salary;
    
    // Default Constructor
    public Employee()
    {
        name   = "<unknown>";
        salary = 0; 
    }  
    
   
    
    
    // Parameterised Constructor
    /*
    public Employee (String employeeName, double currentSalary)
    {
        name = employeeName;
        salary = currentSalary;
    }
    */
    
    public Employee (String name, double salary)
    {
        this.name = name;
        this.salary = salary;
    }

    // Accessors / Getters
    public String getName()
    {
        return name;
    }
    
    public double getSalary()
    {
        return salary;
    }
    
    
    // Mutators / Setters
    
    public void setName(String name)
    {
        if (name.length() < 3)
            JOptionPane.showMessageDialog (null, "Error: name must be at least 3 characters.");
                    
        else
             this.name = name;
    }
    
    public void setSalary (double salary)
    {
        if (salary < 0)
            JOptionPane.showMessageDialog (null, "Error: salary cannot be less than 0.");
        else
            this.salary = salary;
    }
    
    public void raiseSalary(double percent)
    {
        //salary = salary + salary * percent / 100.0;
        salary += salary * percent / 100.0;
    }

    /* Programer's friend
    gets Java to do more checking for us at compiel time
    to make sure ther method we claim to be Overriding exists in a parent class
    and that it has exactly the same finger prints: same type, same access modifier, same name, samae parameters, etc
    */
    @Override
    public String toString()
    {
        return name + " has a salary of $" + salary;
    }
    

}
