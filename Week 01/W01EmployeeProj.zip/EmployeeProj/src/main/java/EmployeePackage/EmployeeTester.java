/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeePackage;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class EmployeeTester 
{
    public static void main (String[] args)
    {
        //System.out.println (args[0]);
        //System.out.println (args[1]);
        
        
        /*
        Employee emp1 = new Employee();
        Employee emp2 = new Employee ("Frankie", 100);
        Employee emp3 = new Employee ("Bella",   125);
        
        
        //System.out.println (emp1.getName() + " has a salary of $" + emp1.getSalary() );
        //System.out.println (emp2.getName() + " has a salary of $" + emp2.getSalary() );
        System.out.println (emp1.toString() );
        System.out.println (emp2.toString() );
        System.out.println (emp3.toString() );


        emp2.raiseSalary (10.0);
        emp2.setName ("Frank");
        
        System.out.println (emp1.toString() );
        System.out.println (emp2.toString() );
        System.out.println (emp3.toString() );

        System.out.println (emp1 );
        System.out.println (emp2 );
        System.out.println (emp3 );
        */
        
        int[] arrayInts = new int[10];      // 0 - 9
        String[] names  = new String[100];  // 0 - 99
                
        Employee[] emps = new Employee [10];

        emps[0] = new Employee ();
        emps[1] = new Employee ("Frankie", 100);
        emps[2] = new Employee ("Bella",   125);        
        
        for (int k = 0; k < emps.length; k++) // Counter Controlled For Loop
        {
            if (emps[k] != null)
                System.out.println (emps[k]);
        }
        
        for (Employee emp : emps) // Enhanced For Loop
        {
            if (emp != null)
                System.out.println (emp);
        }
        
        // ArrayList
        ArrayList<Employee> empsArrayList = new ArrayList<> ();
        
        empsArrayList.add (new Employee () );
        empsArrayList.add (new Employee ("Frankie", 100) );
        empsArrayList.add (new Employee ("Bella",   125) );

        for (int k = 0; k < empsArrayList.size(); k++)
        {
            System.out.println (empsArrayList.get(k) );
        }

        
        for (Employee emp : empsArrayList) // Enhanced For Loop
        {
            //if (emp != null)
                System.out.println (emp);
        }
        

    }
}
