/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08genericmethods;

/**
 *
 * @author omalleym
 */
public class W08GenericMethods 
{
    /*
    public static void printArray (String[] arr)
    {
        for (int k = 0; k < arr.length; k++)
        {
            System.out.println ( (k+1) + ". " + arr[k] );
        }
    }

    public static void printArray (double[] arr)
    {
        for (int k = 0; k < arr.length; k++)
        {
            System.out.println ( (k+1) + ". " + arr[k] );
        }
    }
    */
    
    /*
    public static void printArray (Object[] arr)
    {
        for (int k = 0; k < arr.length; k++)
        {
            System.out.println ( (k+1) + ". " + arr[k] );
        }
    }
    */

    
    public static <T> void printArray (T[] arr)
    {
        /*
        for (int k = 0; k < arr.length; k++)
        {
            System.out.println ( (k+1) + ". " + arr[k] );
        }
        */
        printArray (arr, 0, arr.length - 1);
    }

    // Overloading / Polymorphism = many forms
    public static <T> void printArray (T[] arr, int fromIndex, int toIndex)
    {
        if (fromIndex < 0)               fromIndex = 0;
        if (toIndex   < 0)               toIndex   = 0;
        if (toIndex   > arr.length - 1)  toIndex   = arr.length - 1;
        if (fromIndex > toIndex)         fromIndex = toIndex;

        for (int k = fromIndex; k <= toIndex; k++)
        {
            System.out.println ( (k+1) + ". " + arr[k] );
        }
    }



    /*
    public static <T extends Number> void printArray (T[] arr)
    {
        for (int k = 0; k < arr.length; k++)
        {
            System.out.println ( (k+1) + ". " + arr[k] );
        }
    }
    */
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        String[] names = {"Frankie", "Bella", "Saminal", "Hank", "Teenie", "Ben"};
        printArray (names);
        
        System.out.println ("");
        printArray (names, 1, 2);

        System.out.println ("");
        printArray (names, -1, 2);

        System.out.println ("");
        printArray (names, 1, 99);


        System.out.println ("");
        Double[] doubles = {5.5, 7.87};
        printArray (doubles);
        
        Character[] characters = {'Q', 'W', 'E', 'R', 'T', 'Y'};
        printArray (characters);
        
        Integer[] integers = {1,2,3,4,5};
        printArray (integers);
        
        Long[] longs = {1L, 4L};
        printArray (longs);
        
        Byte[] bytes = {6,7,8,9};
        printArray (bytes);
        
        //Float[] floats = { new Float (1.1), new Float (3.3) };
        Float[] floats = { 1.1f, 3.3f};
        printArray (floats);
        
                
    }
    
}
