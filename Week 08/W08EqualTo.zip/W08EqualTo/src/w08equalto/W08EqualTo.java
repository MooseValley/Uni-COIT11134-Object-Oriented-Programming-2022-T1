/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w08equalto;

import java.util.Scanner;

/**
 *
 * @author omalleym
 */
public class W08EqualTo 
{

    
   // test whether two generic types are equal
   public static < T > boolean isEqualTo( T first, T second )
   {
        // …… complete missing codes

        return first.equals (second);
   } // end method isEqualTo

   
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        String s1 = "Mike";
        String s2 = "Frankie";
        
        System.out.println (isEqualTo (s1, s2) );

        
        
        
        
      Scanner scanner = new Scanner( System.in );
      
      Integer a; // Integers used for
      Integer b; // testing equality

      // test if two Integers input by user are equal
      System.out.print( "Enter two integer values: " );
      a = scanner.nextInt(); // get first integer
      b = scanner.nextInt(); // get second integer
      System.out.printf( "%d and %d are %s\n", a, b,
         ( isEqualTo( a, b ) ? "equal" : "not equal" ) );


    /* Declare two String variables; receive their values from user input and test whether they are equal 
    */
    // declaring String variables
      String c; // Strings used for
      String d; // testing equality

      // test if two Strings input by user are equal
      // …… complete missing codes

      scanner.nextLine(); // Clear input Buffer
      
      System.out.print( "Enter two String values: " );
      c = scanner.nextLine(); // get first 
      d = scanner.nextLine(); // get second 
      System.out.printf( "%s and %s are %s\n", c, d,
         ( isEqualTo( c, d ) ? "equal" : "not equal" ) );      
      
      
    /* Declare two Double variables; receive their values from user input and test whether they are equal 
      */
      //declare two Double variables
      // …… complete missing codes
      // test if two Doubles input by user are equal
      // …… complete missing codes

      Double d1;
      Double d2;
        System.out.print( "Enter two Double values: " );
      d1 = scanner.nextDouble(); // get first 
      d2 = scanner.nextDouble(); // get second 
      System.out.printf( "%f and %f are %s\n", d1, d2,
         ( isEqualTo( d1, d2) ? "equal" : "not equal" ) );      


    }
    
}
