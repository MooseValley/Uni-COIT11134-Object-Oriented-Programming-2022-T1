/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
/*

Java GUI program
* everything in 1 file, including the kitchen sink
* hard to test / debug / understand

Java GUI program
* very nicely separated into separate files
* much easier test / debug / understand
* Very reusable

Model View Controller (MVC)
* as above, but better
* Models: is you data classes.  e.g. Employee, Person, Product, etc
* Views: these are the GUI "windows" that interact with the user - show output, get input, etc.  e.g. Main menu, Create Employee, Display all Employees, etc
* Controllers: this is the brains of the ap.  The processing that is done when a user clicks a button, etc

*/


/**
 *
 * @author omalleym
 */
public class W05Demo extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
