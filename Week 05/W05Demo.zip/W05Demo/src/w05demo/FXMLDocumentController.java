/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05demo;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable 
{
    private static final ObservableList<String> CITIES_ObservableList = FXCollections.observableArrayList ("Rockhampton", "Paris", "London");
    
    @FXML
    private Label label;
    @FXML
    private Button button;
    @FXML
    private Label headingLabel;
    @FXML
    private Button updateHeadingsButton;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextArea outputTextArea;
    @FXML
    private Button addButton;
    @FXML
    private CheckBox over25CheckBox;
    @FXML
    private ComboBox<String> citiesComboBox; // Was ?, change to String
    @FXML
    private RadioButton economyRadioButton;
    @FXML
    private RadioButton firstClassRadioButton;
    @FXML
    private RadioButton businessRadioButton;
    @FXML
    private RadioButton mastercardPaymentRadioButton;
    @FXML
    private RadioButton visaPaymentRadioButton;
    @FXML
    private RadioButton cashPaymentRadioButton;
    @FXML
    private Button clearButton;
    @FXML
    private Button gotoScene2;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        outputTextArea.setEditable (false);
        outputTextArea.setFont (new Font ("Courier New", 12)); // all chars the same width now !!
        
        clear();
        
        
        ToggleGroup paymentMethodsToggleGroup = new ToggleGroup ();
        cashPaymentRadioButton.setToggleGroup (paymentMethodsToggleGroup);
        visaPaymentRadioButton.setToggleGroup (paymentMethodsToggleGroup);
        mastercardPaymentRadioButton.setToggleGroup (paymentMethodsToggleGroup);
        
        visaPaymentRadioButton.setSelected (true);
        
        ToggleGroup classToggleGroup = new ToggleGroup ();
        economyRadioButton.setToggleGroup (classToggleGroup);
        firstClassRadioButton.setToggleGroup (classToggleGroup);
        businessRadioButton.setToggleGroup (classToggleGroup);
        
        economyRadioButton.setSelected (true);
        
        //citiesComboBox.getItems().addAll (CITIES_ObservableList);
        //citiesComboBox.addAll (CITIES_ObservableList);
        
        citiesComboBox.getItems().addAll ("Rockhampton", "Paris", "London");
    }    

    @FXML
    private void updateHeadingsButtonHandler(ActionEvent event) {
        Date today = new Date();
        
        headingLabel.setText ("Today is: " + today);
    }

    @FXML
    private void addButtonHandler(ActionEvent event) {
        String name = nameTextField.getText();
        
        if ((name == null) || (name.length() < 3) )
        {
            JOptionPane.showMessageDialog (null, "Error: name must be at least 3 characters long.");
            return;
        }
        
        String paymentMethodStr = "";
        if (cashPaymentRadioButton.isSelected() == true)
            paymentMethodStr = cashPaymentRadioButton.getText(); // "Cash";
        else if (visaPaymentRadioButton.isSelected() == true)
            paymentMethodStr = visaPaymentRadioButton.getText(); // "Visa";
        else if (mastercardPaymentRadioButton.isSelected() == true)
            paymentMethodStr = mastercardPaymentRadioButton.getText(); // "Mastercard";
        else
        {
            JOptionPane.showMessageDialog (null, "Error: please select a payment type.");
            return;
        }
        
        
        String over25Str = "";
        if (over25CheckBox.isSelected() == true)
            over25Str = "Over 25";
        else
            over25Str = "25 or under";
        
        String cityStr = (String) citiesComboBox.getValue(); // was getSelectedItem()
        if (cityStr == null) 
        {
            JOptionPane.showMessageDialog (null, "Error: please select a city.");
            return;
        }
                
        outputTextArea.setText ( outputTextArea.getText()                  +
                                 String.format ("%-25s", name)             + " " + 
                                 String.format ("%-15s", cityStr)          + " " + 
                                 String.format ("%-15s", paymentMethodStr) + " " + 
                                 String.format ("%-15s", over25Str)        + " " +
                                 "\n");        
    }

    @FXML
    private void clearButtonHandler(ActionEvent event) {
        clear();
    }

    private void clear ()
    {
        outputTextArea.setText ( String.format ("%-25s", "Name")           + " " + 
                                 String.format ("%-15s", "City")           + " " + 
                                 String.format ("%-15s", "Payment Method") + " " + 
                                 String.format ("%-15s", "Over 25")        + " " +
                                 "\n\n");        
    }

    @FXML
    private void gotoScene2Handler(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene2.fxml"));
        
        Scene scene = new Scene(root);
        Stage stage = new Stage ();
        
        stage.setScene(scene);
        stage.show();    }
}
