/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w05swingdemo;

import java.awt.FlowLayout;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Label;

/*

AWT  ->  Swing -> JavaFX

AWT
* basic components, same as OS

Swing
* More components, sexier, more options

JavaFX
* Charts
* DatePicker


*/

/**
 *
 * @author omalleym
 */
public class W05SwingDemo extends JFrame
{
    JButton calcButton    = new JButton ("Calc");
    JLabel  outputLabel   = new JLabel ("");
    
    public W05SwingDemo ()
    {
        this.setLayout (new FlowLayout () );
        
        add (calcButton);
        add (outputLabel);
        
        
        calcButton.addActionListener (event -> calc() );
    }
    
    private void calc()
    {
        Date today = new Date();
        
        outputLabel.setText ("The time is now: " + today);
    }
            
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        W05SwingDemo app = new W05SwingDemo ();

        app.setSize (600, 400);
        app.setLocation (50, 50);
        app.setDefaultCloseOperation  (JFrame.EXIT_ON_CLOSE);
        app.setVisible (true);
    }
    
}
