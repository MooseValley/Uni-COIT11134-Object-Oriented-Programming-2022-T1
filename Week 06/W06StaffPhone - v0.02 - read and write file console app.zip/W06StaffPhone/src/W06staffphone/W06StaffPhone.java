/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W06staffphone;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Formatter;

/**
 *
 * @author omalleym
 */
public class W06StaffPhone extends Application {
    
    private static ArrayList<String> staffPhoneArrayList = new ArrayList<>();
    
    
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    
    public static void readFile ()  //throws FileNotFoundException
    {
        try
        {
            Scanner inFile = new Scanner (new FileReader("staffphone.txt") );

            while (inFile.hasNextLine() == true)
            {
                String inStr = inFile.nextLine();
                
                staffPhoneArrayList.add (inStr);

                System.out.println (inStr);
            }
            
            System.out.println (staffPhoneArrayList.size() + " staff phones read.");

            inFile.close();
        }
        catch (FileNotFoundException err)
        {
            // Do NOT fail silently.
            err.printStackTrace();
            
            System.out.println ("File NOT found.");
        }
    }
    
    public static void writeFile ()
    {
        try
        {
            Formatter outFile = new Formatter ("staffphone2.txt");

            for (String s : staffPhoneArrayList)
            {
                outFile.format ("%s", s + "\n");
            }

            outFile.close();
        }
        catch (FileNotFoundException err)
        {
            // Do NOT fail silently.
            err.printStackTrace();
            
            System.out.println ("File NOT found.");
        }
    }
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //launch(args);
        
        readFile ();
        
        writeFile ();
        
    }
    
}
