/*

TODO / Suggested Homework
* Add a Staff class which has name and phone as instance fields

* Change ArrayList of String to ArrayList of Staff
i.e. change
    private static ArrayList<String> staffPhoneArrayList = new ArrayList<>();
to:
    private static ArrayList<Staff> staffPhoneArrayList = new ArrayList<>();

* Display Staff data neatly in columns
set font to non-proportional, use String.format (%-25s, name), etc

*/



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W06staffphone;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Formatter;

/**
 *
 * @author omalleym
 */
public class W06StaffPhone extends Application {
    
    public static final String      STAFF_PHONE_FILE_NAME = "staffphone.txt";
    
    private static ArrayList<String> staffPhoneArrayList = new ArrayList<>();
    
    
    
    @Override
    public void start(Stage stage) throws Exception 
    {
        readFile ();

        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    
    public static void readFile ()  //throws FileNotFoundException
    {
        try
        {
            Scanner inFile = new Scanner (new FileReader(STAFF_PHONE_FILE_NAME) );

            while (inFile.hasNextLine() == true)
            {
                String inStr = inFile.nextLine();
                
                staffPhoneArrayList.add (inStr);

                System.out.println (inStr);
            }
            
            System.out.println (staffPhoneArrayList.size() + " staff phones read from '" + STAFF_PHONE_FILE_NAME + "'.");

            inFile.close();
        }
        catch (Exception err) // FileNotFoundException
        {
            // Do NOT fail silently.
            err.printStackTrace();
            
            System.out.println ("ERROR: File NOT found: '" + STAFF_PHONE_FILE_NAME + "'.");
        }
    }
    
    public static void writeFile ()
    {
        try
        {
            Formatter outFile = new Formatter (STAFF_PHONE_FILE_NAME);

            for (String s : staffPhoneArrayList)
            {
                outFile.format ("%s", s + "\n");
            }

            outFile.close();
            
            System.out.println (staffPhoneArrayList.size() + " staff phones written to '" + STAFF_PHONE_FILE_NAME + "'.");
        }
        catch (FileNotFoundException err)
        {
            // Do NOT fail silently.
            err.printStackTrace();
            
            System.out.println ("ERROR: File NOT found: '" + STAFF_PHONE_FILE_NAME + "'.");
        }
    }
    
    
    
    public static ArrayList<String> getStaffPhoneArrayList ()
    {
        return staffPhoneArrayList;
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        
       
        //writeFile ();
        
    }
    
}
