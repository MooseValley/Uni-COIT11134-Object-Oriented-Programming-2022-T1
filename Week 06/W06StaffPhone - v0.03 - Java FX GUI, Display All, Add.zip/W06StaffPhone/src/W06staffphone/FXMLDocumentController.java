/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W06staffphone;

import static W06staffphone.W06StaffPhone.writeFile;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button displayEmployeePhoneNumbersButton;
    @FXML
    private Button exitButton;
    @FXML
    private TextArea displayTextArea;
    @FXML
    private Label outputLabel;
    @FXML
    private Button clearButton;
    @FXML
    private Button addButton;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        displayTextArea.setEditable (false);
        
        updateDisplayTextArea ();
    }    

    @FXML
    private void displayEmployeePhoneNumbersButtonHandler(ActionEvent event) 
    {
        updateDisplayTextArea ();
    }


    private void updateDisplayTextArea ()
    {
        ArrayList<String> staffPhoneArrayList = W06StaffPhone.getStaffPhoneArrayList ();
        
        displayTextArea.setText ("");
        
        for (String s : staffPhoneArrayList)
        {
            displayTextArea.appendText (s + "\n");
            //displayTextArea.setText (displayTextArea.getText () + s + "\n");
        }
        
        outputLabel.setText (staffPhoneArrayList.size() + " staff phones loaded from file '" + W06StaffPhone.STAFF_PHONE_FILE_NAME + "'.");
    }


    @FXML
    private void exitButtonHandler(ActionEvent event) {
        
        W06StaffPhone.writeFile ();
        
        System.exit (0);
    }

    @FXML
    private void clearButtonHandler(ActionEvent event) {
        displayTextArea.setText ("");

        outputLabel.setText ("Staff phones cleared.");
    }

    @FXML
    private void addButtonHandler(ActionEvent event) throws IOException
    {
        /*
        Parent root = FXMLLoader.load(getClass().getResource("StaffPhoneAdd.fxml"));
        
        Scene scene = new Scene(root);
        
        //Stage stage = new Stage();
        Stage stage = (Stage)((Node) event.getSource() ).getScene().getWindow();
        
        stage.setScene(scene);
        stage.show();
        */
        Utility.changeScene (getClass(), event, "StaffPhoneAdd.fxml");
    }
    
}
