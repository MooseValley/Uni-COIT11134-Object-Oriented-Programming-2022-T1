/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package W06staffphone;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author omalleym
 */
public class StaffPhoneAddController implements Initializable {

    @FXML
    private Button addButton;
    @FXML
    private Button returnButton;
    @FXML
    private TextField staffNameTextField;
    @FXML
    private TextField staffPhoneTextField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void addButtonHandler(ActionEvent event) 
    {
        // TODO:
        // * Check name and phone do NOT contain commas
        
        String staffNameStr  = staffNameTextField.getText().trim();
        String staffPhoneStr = staffPhoneTextField.getText().trim();
         
        if (staffNameStr.length() < 3)
            JOptionPane.showMessageDialog (null, "ERROR: name must be at least 3 characters long.");
        else if (staffPhoneStr.length() < 8)
            JOptionPane.showMessageDialog (null, "ERROR: phone must be at least 8 characters long.");
        else
        {
            ArrayList<String> staffPhoneArrayList = W06StaffPhone.getStaffPhoneArrayList ();
            
            staffPhoneArrayList.add (staffNameStr  + ", " + staffPhoneStr);
            
            staffNameTextField.setText("");
            staffPhoneTextField.setText("");
            
            JOptionPane.showMessageDialog (null, "New Staff Phone added to the list: " + "\n" +
                                                 "* Staff Name:  " + staffNameStr      + "\n" +
                                                 "* Staff Phone: " + staffPhoneStr     + "\n" );
        }
    }

    @FXML
    private void returnButtonHandler(ActionEvent event)  throws IOException
    {
        /*
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        //Stage stage = new Stage();
        Stage stage = (Stage)((Node) event.getSource() ).getScene().getWindow();
        stage.setScene(scene);
        stage.show();    
        */
        Utility.changeScene (getClass(), event, "FXMLDocument.fxml");
    }
}
