/*
2. Implement a Java program that uses a LinkedList  to store Integer objects that have the following 
values from an array

Integer [ ] arr = {-1, 17, 28, -39, 12, 6, -2, -10};

Use an iterator to traverse the LinkedList and replace each negative value by the corresponding 
positive number and doubled. Print out the contents of the resulting list.

 */
package w10q02linkedlistintegers;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author omalleym
 */
public class W10Q02LinkedListIntegers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        Integer [ ] arr = {-1, 17, 28, -39, 12, 6, -2, -10};
        
        LinkedList<Integer> integerLinkedList = new LinkedList<>();
        ListIterator<Integer> iter;


        for (int k = 0; k < arr.length; k++)
        {
            integerLinkedList.add (arr[k] );
        }
        
        iter = integerLinkedList.listIterator(); 

        System.out.println ("\nIterator:");
        while (iter.hasNext() == true)
        {
            System.out.print (iter.next() + ", ");
        }

        iter = integerLinkedList.listIterator();  // Move iter back to start !
        while (iter.hasNext() == true)
        {
            Integer k = iter.next();
            
            if (k < 0)
            {
                //iter.previous(); // DO NOT need this:  set points to the node returned by next / previous !
                iter.set (-1 * k * 2);
            }
        }
        
        System.out.println ("\nFor Loop:");
        for (Integer k : integerLinkedList)
            System.out.print (k + ", ");
        

        iter = integerLinkedList.listIterator();  // Move iter back to start !
        System.out.println ("\nIterator:");
        while (iter.hasNext() == true)
        {
            System.out.print (iter.next() + ", ");
        }

        System.out.println ();
    }
    
}
