/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w10q03studentlinkedlistgui;


import java.net.URL;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javax.swing.JOptionPane;

/**
 *
 * @author omalleym
 */
public class FXMLDocumentController implements Initializable 
{
    @FXML
    private Label label;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField studIdTextField;
    @FXML
    private Button addButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button displayAllButton;
    @FXML
    private Button exitButton;
    
    LinkedList<StudentEmail> studentEmailLinkedList = new LinkedList<>();
    @FXML
    private TextArea outputTextArea;
    

    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        outputTextArea.setEditable (false);
        outputTextArea.setFont (new Font ("Courier New", 14) );
    }    

    @FXML
    private void addButtonHandler(ActionEvent event) 
    {
        String nameStr   = nameTextField.getText().trim();
        String studIdStr = studIdTextField.getText().trim();
        
        boolean dataValid = true;
        
        if (dataValid == true)
        {
            if (nameStr.length() < 3)
            {
                JOptionPane.showMessageDialog (null, "Error: name must be at least 3 characters long.");
                dataValid = false;
            }
        }
        
        if (dataValid == true)
        {
            studIdStr = studIdStr.toLowerCase();
            
            if (studIdStr.length() != 6)
            {
                JOptionPane.showMessageDialog (null, "Error: Stud Id must be at 6 characters long.");
                dataValid = false;
            }
            else if (studIdStr.charAt(0) != 's')
            {
                JOptionPane.showMessageDialog (null, "Error: Stud Id must start with an 's'.");
                dataValid = false;
            }
        }

        if (dataValid == true)
        {
            StudentEmail stud = new StudentEmail (nameStr, studIdStr);
            
            studentEmailLinkedList.add (stud);
            
            // Clear inputs
            nameTextField.setText("");
            studIdTextField.setText("");
        }
    }

    @FXML
    private void deleteButtonHandler(ActionEvent event) 
    {
        String nameStr   = nameTextField.getText().trim();
        
        if (nameStr.length() == 0)
        {
            JOptionPane.showMessageDialog (null, "Error: cannot search on a blank name.");
            return;
        }
        
        ListIterator<StudentEmail> iter = studentEmailLinkedList.listIterator();
        int count = 0;
        
        while (iter.hasNext() == true)
        {
            StudentEmail stud = iter.next();
            
            if (stud.getName().compareToIgnoreCase (nameStr) == 0)
            {
                iter.remove();
                count++;
            }
        }

        if (count == 0)
            JOptionPane.showMessageDialog (null, "Error: No students with name '" + nameStr + "' were found.");
        else
            JOptionPane.showMessageDialog (null, "Success: " + count + " students with name '" + nameStr + "' were deleted.");
    }

    @FXML
    private void displayAllButtonHandler(ActionEvent event) 
    {
        StringBuffer sb = new StringBuffer();
        
        outputTextArea.setText("");

        ListIterator<StudentEmail> iter = studentEmailLinkedList.listIterator();
        
        while (iter.hasNext() == true)
        {
            sb.append (iter.next() + "\n" );
        }        

        outputTextArea.setText (sb.toString() );
    }
    

    @FXML
    private void exitButtonHandler(ActionEvent event) 
    {
        System.exit (0);
    }
    
}
