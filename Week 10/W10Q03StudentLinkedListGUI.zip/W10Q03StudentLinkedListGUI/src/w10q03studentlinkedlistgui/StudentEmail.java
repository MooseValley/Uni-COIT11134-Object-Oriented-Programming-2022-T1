/*
 Author: Mike O'Malley
 Source: StudentEmail.java
Descrtn: TBA ... :)

Ammendment History
Ver   Date        Author    Details
----- ----------- --------  ---------------------------------------------------
0.001 19-May-2022 Mike O    Created.

*/
package w10q03studentlinkedlistgui;

public class StudentEmail
{

   // Class Data:
   private String  name;
   private String  studId;

   // Default Consructor:
   public StudentEmail ()
   {
      this ("", "");
   }

   // Parameterised Consructor:
   public StudentEmail (String name, String studId)
   {
      this.name   = name;
      this.studId = studId;
   }

   // Accessors / Getters:

   public String getName ()
   {
      return name;
   }

   public String getStudId ()
   {
      return studId;
   }

   public String getEmail ()
   {
      return studId + "@cqu.edu.au";
   }

   // Mutators / Setters:

   public void setName (String name)
   {
      this.name = name;
   }

   public void setStudId (String studId)
   {
      this.studId = studId;
   }

   @Override
   public String toString ()
   {
      return 
         String.format ("%-25s", name)           + " " + 
         String.format ("%-10s", studId)         + " " + 
         String.format ("%-25s", getEmail () )   + " " + 
         "";
   }

} // StudentEmail
