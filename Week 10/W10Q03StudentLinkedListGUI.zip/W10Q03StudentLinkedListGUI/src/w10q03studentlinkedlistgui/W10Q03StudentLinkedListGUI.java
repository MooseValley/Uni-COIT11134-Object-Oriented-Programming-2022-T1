/*
3. Write a Java class named StudentEmail that has data members for the name, number of a student. 
The class should have a constructor and appropriate accessor and mutator methods. In addition, the 
toString      method should include the output information with student name, student number and 
the corresponding e-mail address. The e-mail address is a string with the student number 
and @cqu.edu.au (such as   s1001222@cqu.edu.au). 

Write a program that creates a GUI with the following:

•	two labelled text fields, for name and student number
•	a text area to display the information 
•	four buttons – ‘add’, ‘delete’, ‘display all’ and ‘exit’

When the buttons are pressed appropriate actions as mentioned below have to be performed:

Add button pressed: - display the student information in the text area; add the student 
information to the linked list.

Delete button pressed: - If the student name, from the name text field, is found in the linked list, 
then it is removed from the linked list; if it is not found, then an appropriate error message is displayed.

Display all button pressed: - All data (StudentEmail objects) that are stored in the linked list are 
displayed in the text area.

Exit button pressed: - The program is terminated.

 */
package w10q03studentlinkedlistgui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author omalleym
 */
public class W10Q03StudentLinkedListGUI extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
