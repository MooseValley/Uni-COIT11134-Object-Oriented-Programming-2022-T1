/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buildingproject;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class BuildingTester {
    public static void main (String[] args)
    {
        /*
        Building b1 = new Building ();
        Building b2 = new Building ("123 Uni Rd", 222.5);
        
        House h1    = new House ();
        House h2    = new House ("678 Smith St", 200.5, 4, 2, 1);
        
        System.out.println (b1);
        System.out.println (b2);

        System.out.println (h1);
        System.out.println (h2);
        */
        
        
        // *** Homework:
        
        // Use an Array
        // For Loops: Counter and Enhanced
        System.out.println ("*** Array:");
        Building[] buldingsArray = new Building [10];
        
        buldingsArray[0] = new Building ("123 Uni Rd",    222.50);
        buldingsArray[1] = new House    ("678 Smith St",  200.50, 4, 2, 1);
        buldingsArray[2] = new Building ("417 Marine Rd", 344.15);
        buldingsArray[3] = new House    ("22 Rocky St",   188.75, 3, 1, 2);
        
        System.out.println ("\nCounter Controlled For loop ...");
        for (int k = 0; k < buldingsArray.length; k++)
        {
            if (buldingsArray[k] != null)
                System.out.println (buldingsArray[k]);
        }
        
        System.out.println ("\nEnhanced For loop ...");
        for (Building b : buldingsArray)
        {
            if (b != null)
                System.out.println (b);
        }
        
        // Get the total of the number of bedrooms
        int totalBedrooms = 0;
        for (Building b : buldingsArray)
        {
            if (b != null)
                if (b instanceof House)
                    totalBedrooms += ((House) b).getNumBedrooms ();
        }
        
        int totalBedrooms2 = 0;
        for (int k = 0; k < buldingsArray.length; k++)
        {
            if (buldingsArray[k] != null)
                if (buldingsArray[k] instanceof House)
                    totalBedrooms2 += ((House) buldingsArray[k]).getNumBedrooms ();
        }

        System.out.println ("Total bedrooms for all Houses = " + totalBedrooms);
        System.out.println ("Total bedrooms for all Houses = " + totalBedrooms2);
        
        
/*
        
        
*/
        
        // Use an ArrayList
        // For Loops: Counter and Enhanced
        System.out.println ("*** ArrayList:");
        ArrayList<Building> buildingsArrayList = new ArrayList<>();
        
        buildingsArrayList.add (new Building ("123 Uni Rd",    222.50) );
        buildingsArrayList.add (new House    ("678 Smith St",  200.50, 4, 2, 1) );
        buildingsArrayList.add (new Building ("417 Marine Rd", 344.15) );
        buildingsArrayList.add (new House    ("22 Rocky St",   188.75, 3, 1, 2) );
        
        System.out.println ("\nCounter Controlled For loop ...");
        for (int k = 0; k < buildingsArrayList.size(); k++)
        {
            if (buildingsArrayList.get(k) != null)
                System.out.println (buildingsArrayList.get(k));
        }
        
        System.out.println ("\nEnhanced For loop ...");
        for (Building b : buildingsArrayList)
        {
            if (b != null)
                System.out.println (b);
        }
        


    }            
}
