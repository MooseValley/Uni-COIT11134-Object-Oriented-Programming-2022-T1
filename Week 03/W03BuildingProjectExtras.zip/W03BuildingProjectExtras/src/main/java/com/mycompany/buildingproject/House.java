/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buildingproject;

/**
 *
 * @author omalleym
 */
public class House extends Building {
    private int numBedrooms;
    private int numBathrooms;
    private int numGarages;
    
    // Default Constructor
    public House ()
    {
        this ("", 0.0, 0, 0, 0); // Call Parameterised Constructor
    }
    
    // Parameterised Constructor
    public House (String address, double builtArea, int numBedrooms, int numBathrooms, int numGarages)
    {
        super (address, builtArea);
        
        this.numBedrooms  = numBedrooms;
        this.numBathrooms = numBathrooms;
        this.numGarages   = numGarages;
    }
    
    // Accessors
    
    public int getNumBedrooms ()
    {
        return numBedrooms;
    }

    public int getNumBathrooms ()
    {
        return numBathrooms;
    }

    public int getNumGarages ()
    {
        return numGarages;
    }
    
    // Mutators
    public void setNumBedrooms (int numBedrooms)
    {
        this.numBedrooms = numBedrooms;
    }

    public void setNumBathrooms (int numBathrooms)
    {
        this.numBathrooms = numBathrooms;
    }

    public void setNumGarages (int numGarages)
    {
        this.numGarages = numGarages;
    }
    
    @Override
    public String toString()
    {
        return super.toString() +
               ", Beds: "    + numBedrooms + 
               ", Baths: "   + numBathrooms +
               ", Garages: " + numGarages;
    }

}
