/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03patients;

/**
 *
 * @author omalleym
 */
public abstract class Patient {
    private String name;
    private Type atribute2;
    private Type atribute3;
    
    public String getName()
    {
        return name;
    }
    
    public abstract  void operation2 ();
    
    
    /*
    public Patient ()
    {
        this ("");
    }
    
    public Patient (String name)
    {
        this.name = name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    @Override
    public String toString()
    {
        return name;
    }
    */
}
