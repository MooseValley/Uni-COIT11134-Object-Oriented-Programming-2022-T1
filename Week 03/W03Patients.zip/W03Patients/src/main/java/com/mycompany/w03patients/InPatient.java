/*
ASSUMPTIONS:
I am answering the question and only providing exactly what is asked for.
I assume Attribute 2 is a type in InPatient - it should be Admission Date.
Question does NOT ask for Constructors, mutators, toSWtring, etc.

*/
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03patients;

/**
 *
 * @author omalleym
 */
public class InPatient {
    private int bedNum;
    private String admissionDate; // See ASSUMPTIONS above.
    
    
    public void operation1()
    {
        // TODO
    }
    
    public void operation2()
    {
        // TODO
    }

    
    /*
    public InPatient ()
    {
        
    }

    public InPatient (String name, int bedNum, String admissionDate)
    {
        super (name);
        this.bedNum = bedNum;
        this.admissionDate = admissionDate;
    }
    
    public int getNedNum()
    {
        return bedNum;
    }
    
    public String getAdmissionDate ()
    {
        return admissionDate;
    }
    
    public void setBedNum ()
    {
        
    }
*/
    
}
