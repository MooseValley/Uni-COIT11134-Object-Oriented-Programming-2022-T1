/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03employeeandworker;

/**
 *
 * @author omalleym
 */
public class PieceWorker extends Employee {
    
    private double wagePerPiece;
    private int    numPieces;
    
    public PieceWorker ()
    {
        this ("", "", "", 0.0, 0);
    }
    
    public PieceWorker (String firstName, String lastName, String socialSecurityNumber, double wagePerPiece, int numPieces)
    {
        super (firstName, lastName, socialSecurityNumber);  // Must be the first line of code
        
        this.wagePerPiece = wagePerPiece;
        this.numPieces    = numPieces;
    }
    
    // Accessors
    
    public double getWagePerPiece ()
    {
        return wagePerPiece;
    }
    
    public int getNumPieces ()
    {
        return numPieces;
    }
    
    // Mutators
    
    public void setWagePerPiece (double wagePerPiece)
    {
        this.wagePerPiece = wagePerPiece;
    }

    public void setNumPieces (int numPieces)
    {
        this.numPieces = numPieces;
    }
    
    @Override
    public String toString ()
    {
        /*
        return super.toString() + 
               ", Rate: "     + String.format ("%,6.2f", wagePerPiece) + 
               ", Pieces: "   + String.format ("%,4d",   numPieces)    + 
               ", Earnings: " + String.format ("%,8.2f", earnings() );
        */

        return super.toString() + 
               String.format ("%,8.2f",  wagePerPiece) + 
               String.format ("%,6d",    numPieces)    + 
               String.format ("%,12.2f", earnings() );
    }

    @Override
    public double earnings ()
    {
        return wagePerPiece * numPieces;
    }
}
