/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03employeeandworker;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class EmployeeTester {
    
    
    public static void main (String[] args)
    {
        ArrayList<Employee> employees = new ArrayList<>();
        
        employees.add (new PieceWorker      ("Mike",    "O",      "1234",   10.23,   100) );
        employees.add (new PieceWorker      ("Bella",   "O",      "334455", 93.11454,  7) );
        employees.add (new SalariedEmployee ("Frankie", "Shitzu", "99887",  765.12) );
        employees.add (new SalariedEmployee ("Saminal", "Apso",   "76133",  989.33) );
        
        System.out.println (Employee.toStringColumnHeadings() );
        for (Employee e : employees)
        {
            System.out.println (e);
        }
    }
}
