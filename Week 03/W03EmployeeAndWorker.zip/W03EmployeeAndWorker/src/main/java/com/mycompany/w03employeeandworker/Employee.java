/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03employeeandworker;

/**
 *
 * @author omalleym
 */
public abstract class Employee {
    private String  firstName;
    private String  lastName;
    private String  socialSecurityNumber;
    
    public Employee ()
    {
        this ("", "", "");
    }
        
    public Employee (String firstName, String lastName, String socialSecurityNumber)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
    }
    
    
    // Accessors

    public String getFirstName ()
    {
        return firstName;
    }
    
    public String getLastName ()
    {
        return lastName;
    }
    
    public String getSocialSecurityNumber ()
    {
        return socialSecurityNumber;
    }

    
    // Mutators
    
    public void setFirstName (String firstName)
    {
        this.firstName = firstName;
    }
    
    public void setLastName (String lastName)
    {
        this.lastName = lastName;
    }

    public void setSocialSecurityNumber (String socialSecurityNumber)
    {
        this.socialSecurityNumber = socialSecurityNumber;
    }
    
    
    public static String toStringColumnHeadings()
    {
        return String.format ("%-20s",  "Type")      +
               String.format ("%-20s",  "Name")      +
               String.format ("%-10s",  "SSN")       +
               String.format ("%-10s",  "Pay Rate")  + 
               String.format ("%-8s",   "Pieces")    + 
               String.format ("%-14s",  "Earnings" );
    }

    @Override
    public String toString()
    {
        String classNameStr = this.getClass().getName();
        classNameStr = classNameStr.replace ("com.mycompany.w03employeeandworker.", "");
        
        return String.format ("%-20s", classNameStr)               +
               String.format ("%-20s", firstName + " " + lastName) +
               String.format ("%-10s", socialSecurityNumber);
    }
    
    
    // Abstract method
    public abstract double earnings ();
    
}
