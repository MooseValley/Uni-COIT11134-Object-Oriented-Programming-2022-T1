/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.w03employeeandworker;

/**
 *
 * @author omalleym
 */
public class SalariedEmployee extends Employee {
    
    private double weeklySalary;
    
    public SalariedEmployee ()
    {
        this ("", "", "", 0.0);
    }
    
    public SalariedEmployee (String firstName, String lastName, String socialSecurityNumber, double weeklySalary)
    {
        super (firstName, lastName, socialSecurityNumber);  // Must be the first line of code
        
        this.weeklySalary = weeklySalary;
    }
    
    // Accessors
    
    public double getWeeklySalary ()
    {
        return weeklySalary;
    }
    
    
    // Mutators
    
    public void setWeeklySalary (double weeklySalary)
    {
        this.weeklySalary = weeklySalary;
    }

   
    @Override
    public String toString ()
    {
        return super.toString() + 
               String.format ("%14s",    "") + 
               String.format ("%,12.2f", earnings() );
    }

    @Override
    public double earnings ()
    {
        return weeklySalary;
    }
}
