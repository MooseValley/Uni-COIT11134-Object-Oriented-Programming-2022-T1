/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buildingproject;

/**
 *
 * @author omalleym
 */
public class Building {
    private String address;
    private double builtArea; // Sq Meters
    
    public Building()
    {
        this ("", 0.0);
    }
    
    public Building (String address, double builtArea)
    {
        this.address   = address;
        this.builtArea = builtArea;
    }
    
    // Accessors
    
    public String getAddress()
    {
        return address;
    }
    
    public double getBuiltArea()
    {
        return builtArea;
    }
    
    // Mutators
    
    public void setAddress (String address)
    {
        this.address   = address;
    }
    
    public void setBuiltArea (double builtArea)
    {
        this.builtArea = builtArea;
    }

    @Override
    public String toString()
    {
        return "Address: " + address + ", Area: " + builtArea + "sqm";
    }
}
