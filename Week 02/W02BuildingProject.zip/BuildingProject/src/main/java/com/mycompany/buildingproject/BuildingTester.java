/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buildingproject;

import java.util.ArrayList;

/**
 *
 * @author omalleym
 */
public class BuildingTester {
    public static void main (String[] args)
    {
        Building b1 = new Building ();
        Building b2 = new Building ("123 Uni Rd", 222.5);
        
        House h1    = new House ();
        House h2    = new House ("678 Smith St", 200.5, 4, 2, 1);
        
        System.out.println (b1);
        System.out.println (b2);

        System.out.println (h1);
        System.out.println (h2);
        
        
        // *** Homework:
        
        // Use an array
        // For Loops: Counter and Enhanced
        Building[] buldingsArray = new Building [10];
        
        // :::
        
        // Use an ArrayList
        // For Loops: Counter and Enhanced
        ArrayList<Building> buildingsArrayList = new ArrayList<>();
    }            
}
