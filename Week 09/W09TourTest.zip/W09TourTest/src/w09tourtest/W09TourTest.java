/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w09tourtest;

/**
 *
 * @author omalleym
 */
public class W09TourTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        TourSpecific tour1  =  new TourSpecific("Sydney", 250);
        TourSpecific tour2  =  new TourSpecific("National Parks", 125);

        System.out.println( tour1); 
        System.out.println( tour2);



        TourGeneric tour3  =  new TourGeneric("Sydney", new Double (250.15) );
        TourGeneric tour4  =  new TourGeneric("National Parks", new Double (125.99) );

        System.out.println( tour3); 
        System.out.println( tour4);

        TourGeneric tour5  =  new TourGeneric("Sydney", new Integer (250) );
        TourGeneric tour6  =  new TourGeneric("National Parks", new Integer (125) );

        System.out.println( tour5); 
        System.out.println( tour6);
    }
    
}
